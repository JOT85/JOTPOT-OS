#!/bin/bash
echo "Hello, welcome to JOTPOT OS :)"
node /JPOS/resources/shell/login.js
echo "Bye, hope you have a nice day :)"
sleep 1
